# SI TENEMOS QUE HACER QUE SE INSTALEN LOS MÓDULOS AL EJECUTAR EL ARCHIVO TENEMOS QUE PONER LO SIGUIENTE: Ç
# !pip3 install scp/paramiko/pycrypto/pycryptodome/ftplib/smtplib

# Importación de módulos necesarios
from scp import SCPClient  # Importa el cliente SCP para transferencia segura de archivos
from http.server import BaseHTTPRequestHandler, HTTPServer  # Importa clases para crear un servidor HTTP
import paramiko  # Importa el módulo para realizar conexiones SSH
from Crypto.PublicKey import RSA  # Importa la clase RSA para gestionar claves públicas/privadas RSA
from Crypto.Cipher import AES, PKCS1_OAEP  # Importa módulos para encriptación AES y RSA
import smtplib  # Importa módulo para el envío de correos electrónicos
from ftplib import FTP  # Importa módulo para transferencia de archivos FTP


# Definición de un manejador de peticiones HTTP personalizado
class HelloHandler(BaseHTTPRequestHandler):
    # Método para manejar peticiones HEAD
    def do_HEAD(self):
        self.send_response(200)  # Responde con un código 200 (OK)
        self.send_header('Content-type', 'text/html')  # Especifica el tipo de contenido como HTML
        self.end_headers()  # Finaliza las cabeceras de la respuesta

    # Método para manejar peticiones GET
    def do_GET(self):
        self.do_HEAD()  # Ejecuta la función para enviar cabeceras
        # Envía una respuesta HTML al cliente
        self.wfile.write("""<html><head><title>Hello
            Gorka</title></head><body><p>HelloWorld</p>
            <form method="POST" >
            <input type="submit" value="Click me">
                <img src="https://imgs.search.brave.com/pBeJWe6LJKO24PheFi1S1IkMEiCKTaePqGQnPGY1EOg/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5pc3RvY2twaG90/by5jb20vaWQvMTI2/MTM0MDQyMy92ZWN0/b3IvcmFkaW9hY3Rp/dmUtc3ltYm9sLWlj/b24tc2V0LW51Y2xl/YXItcmFkaWF0aW9u/LXdhcm5pbmctc2ln/bi1hdG9taWMtZW5l/cmd5LWxvZ28tdmVj/dG9yLmpwZz9zPTYx/Mng2MTImdz0wJms9/MjAmYz1kVVhlZVVM/SEwwUzJlN0lEYU1B/TGdoYWtCTFprM0th/MlltSVZLLUNZYml3/PQ">
                        </input>
            </form>
            </body></html>""".encode("utf-8"))  # Codifica la respuesta como UTF-8 y la envía

    # Método para manejar peticiones POST
    def do_POST(self):
        self.do_HEAD()  # Ejecuta la función para enviar cabeceras
        # Respuesta HTML para peticiones POST
        self.wfile.write("""<html><head><title>Hello
            World</title></head><body><p>Form received</p>
            </body></html>""".encode("utf-8"))  # Codifica la respuesta como UTF-8 y la envía
        self.get_Documents()  # Llama al método para obtener documentos
        
    # Método para obtener documentos
    def get_Documents(self):
        #self.subirArchivoSSH()  # Sube archivos a través de SSH
        #self.recuperarArchivoSSH()  # Descargar archivos a través de SSH
        
        
        #self.desEncrypt()  # Desencripta datos
        #self.writeEncryptedDataTofile()  # Escribe datos encriptados en un archivo
        
        
        #self.subirArchivoFTP()  # Sube archivos a través de FTP
        #self.recuperarArchivoFTP()  # Descargar archivos a través de FTP
        
        #self.sendEmail()  # Envía un correo electrónico
        
        return #Lo uso para parar la ejecución del método e ir controlando paso a paso el código y lo que se va ejecutando
        
    # Método para subir archivos a un servidor SSH
    def subirArchivoSSH(self):
        print("Subiendo archivos al SSH")
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
        # Se conecta al servidor SSH con los parámetros especificados
        ssh.connect(hostname='127.0.0.1', port=2222, username='linuxserver', password='password')

        # Crea un cliente SCP para la transferencia segura de archivos
        # Un cliente SCP es un cliente que permite la transferencia segura de archivos entre un host local y un host remoto
        scp = SCPClient(ssh.get_transport())
        
        print("Subiendo archivo suelto al SSH")
        # Sube el archivo al servidor SSH y lo renombra como prueba.txt en la carpeta /config/test
        scp.put('examen.txt', remote_path='/config/test/prueba.txt')  
        
        print("Subiendo archivos con carpeta al SSH")
        #Si necesitamos subir una carpeta con su contenido, usamos el parámetro recursive=True
        scp.put('carpeta', recursive=True, remote_path='/config/test') 
        """
        carpeta es el nombre de la carpeta local y /config/test es el nombre de la carpeta remota que se crea
        
        Por defecto sino indicamos carpeta se guarda en el directorio raíz del servidor SSH que es config
        Si las carpetas no existen, se crean automáticamente al usar el parámetro recursive=True 
        """
        
        scp.close()  # Cierra la conexión SCP
        ssh.close()  # Cierra la conexión SSH
        print("SSH end")
        

    # Método para recuperar archivos de un servidor SSH mediante SCP
    def recuperarArchivoSSH(self):
        #Para conectarnos por ssh tenemos que poner esto en la terminal: ssh -p 2222 linuxserver@localhost
        #Para subir un archivo por ssh tenemos que poner esto en la terminal: scp -P 2222 /home/albertosaz.bin linuxserver@localhost:/home
        print("connect SSH")

        ssh = paramiko.SSHClient()  # Crea un cliente SSH
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # Configura la política de claves faltantes

        # Se conecta al servidor SSH con los parámetros especificados
        ssh.connect(hostname='127.0.0.1', port=2222, username='linuxserver', password='password')

        # Crea un cliente SCP para la transferencia segura de archivos
        # Un cliente SCP es un cliente que permite la transferencia segura de archivos entre un host local y un host remoto
        scp = SCPClient(ssh.get_transport())
        
        #Descarga el archivo encriptado desde el servidor SSH y lo guarda en el directorio local con el nombre encriptado.bin
        scp.get('/home/encrypted_data.bin', local_path='encrypted_data.bin') 
        scp.get('/home/private.pem') # Descarga el archivo de clave privada desde el servidor SSH
        
        scp.close()  # Cierra la conexión SCP
        ssh.close()  # Cierra la conexión SSH
        print("SSH end")


    # Método para desencriptar datos usando la clave privada RSA
    def desEncrypt(self):
        print("Desencriptar")
        
        # Abre el archivo de datos encriptados en modo lectura binaria. ESTE ARCHIVO LO HEMOS DESCARGADO DEL SERVIDOR SSH O FTP
        file_in = open("encrypted_data.bin", "rb") 
        # Importa la clave privada RSA. ESTE ARCHIVO LO HEMOS DESCARGADO DEL SERVIDOR SSH O FTP 
        private_key = RSA.import_key(open("private.pem").read())  
        
        #Sacamos la información encriptada y la guardamos en la variable enc_session_key
        enc_session_key = file_in.read(private_key.size_in_bytes())  
        
        # Cerramos el archivo con los datos encriptados
        file_in.close()  

        # Guardamos la clave privada en la variable cipher_rsa
        cipher_rsa = PKCS1_OAEP.new(private_key)
        
        # Desencripta el archivo obteniendo el contenido y lo guardamos en la variable session_key
        self.session_key = cipher_rsa.decrypt(enc_session_key)  
        
        # Imprime el contenido del archivo desencriptado
        print("Desencriptar finalizado. ESTE ES EL CONTENIDO DEL ARCHIVO : /n" + self.session_key)

    # Método para escribir datos encriptados en un archivo
    def writeEncryptedDataTofile(self):
        # Escribe la clave de sesión en un archivo
        file_out = open("desencriptado.txt", "wb")  # Abre un archivo para escritura binaria wb=(write binary)
        file_out.write(self.session_key) # Escribe la clave de sesión en el archivo
        file_out.close() # Cierra el archivo

    # Método para cargar archivos a través de FTP
    def subirArchivoFTP(self):
        #Para subir un archivo al ftp podemos usar la app FileZilla, que es un cliente FTP, y nos conectamos con los datos que nos da el servidor
        print("Subir archivos al FTP") 

        # Dirección del servidor FTP
        url = '127.0.0.1' 
        port = 21  # Puerto del servidor FTP
        
        # Se conecta al servidor FTP con los parámetros especificados y al finalizar la conexión se cierra automáticamente
        with FTP() as conn:
            conn.connect(url, port)  # Se conecta al servidor FTP con los parámetros especificados   
            # Información del login del servidor FTP
            conn.login('admin', 'preguntaraalberto')  
            # Cambia al directorio raíz del servidor FTP o al que le indiquemos
            conn.cwd('/')  
            # Imprime el directorio actual
            print(conn.pwd())  
            # Obtiene el mensaje de bienvenida del servidor FTP
            print(conn.getwelcome())  
            
            # Crea una carpeta en el servidor FTP si no existe
            if not conn.nlst('/pruebaCarpeta1'):
                conn.mkd('/pruebaCarpeta1') 
            
            # Abre el archivo binario en modo lectura rb=(read binary) y lo sube al servidor FTP
            with open('encrypted_data.bin', 'rb') as file:
                conn.storbinary('STOR /pruebaCarpeta1/encrypted.bin', file)  
                # Sube el archivo al servidor FTP con el nombre albertosaz.bin STOR=(store) hace que se guarde el archivo en el servidor FTP
            
            # Obtiene y muestra el listado de archivos en el servidor FTP con el método listCallback
            conn.retrlines('LIST')   # Se envia al servidor FTP el comando LIST para obtener el listado de archivos en el servidor FTP
            
        print("Upload FTP end")
        
    
    def recuperarArchivoFTP(self):
        print("Recuperar archivos del FTP") 

        # Dirección del servidor FTP
        url = '127.0.0.1' 
        port = 21  # Puerto del servidor FTP
        
        # Se conecta al servidor FTP con los parámetros especificados y al finalizar la conexión se cierra automáticamente
        with FTP() as conn:
            conn.connect(url, port)  # Se conecta al servidor FTP con los parámetros especificados   
            # Información del login del servidor FTP
            conn.login('admin', 'preguntaraalberto')  
            # Cambia al directorio raíz del servidor FTP o al que le indiquemos
            conn.cwd('/')  
            # Imprime el directorio actual
            print(conn.pwd())  
            # Obtiene el mensaje de bienvenida del servidor FTP
            print(conn.getwelcome())  
            
            # Crea un archivo binario en modo escritura wb=(write binary) y lo descarga del servidor FTP con el nombre downloaded_file.txt
            with open("encryptedDescargado.bin", "wb") as file:
                conn.retrbinary("RETR encrypted.bin", file.write) # Descarga el archivo del servidor FTP con el nombre remote_file.txt
            
            # Obtiene y muestra el listado de archivos en el servidor FTP con el método listCallback
            conn.retrlines('LIST')   # Se envia al servidor FTP el comando LIST para obtener el listado de archivos en el servidor FTP
        

    # Método para enviar correos electrónicos
    def sendEmail(self):
        print("Enviar email")
        client = smtplib.SMTP(host='0.0.0.0', port=1025)  # Se conecta al servidor SMTP con los parámetros especificados
        sender = 'alberto@salesioanos.edu'  # Dirección del remitente
        dest = 'apruebame@salesianos.edu'  # Dirección del destinatario
        subject = 'Asunto del correo'  # Asunto del correo
        message = self.sesion_key  # Mensaje a enviar con el contenido del archivo desencriptado
        message_template = 'From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n%s'  # Plantilla del mensaje
        
        # Establece el nivel de depuración en 1. Esto sirve para ver los mensajes que se envían y reciben en la consola
        client.set_debuglevel(1)
        
        # Envía el correo electrónico
        client.sendmail(sender, dest, message_template % (sender, dest, subject, message))
        client.quit()  # Cierra la conexión SMTP
        print("Enviar email end")


# Definición de parámetros para el servidor HTTP
params = '', 8083
# Creación del servidor HTTP con el manejador definido
server = HTTPServer(params, HelloHandler)

# Intento de mantener el servidor en funcionamiento indefinidamente
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass

# Cierre del servidor
server.server_close()